package co.musicshop.fis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicShopApplication.class, args);
    }

}
